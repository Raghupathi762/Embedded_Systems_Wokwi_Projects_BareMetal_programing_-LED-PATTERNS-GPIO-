#include<stdint.h>
#define porta (*(volatile uint8_t*)(0x22))
#define  ddra  (*(volatile uint8_t*)(0x21))
#define portb (*(volatile uint8_t*)(0x25))
#define  ddrb  (*(volatile uint8_t*)(0x24))
void delay()
{
  volatile uint32_t i;
  for(i=0;i<400000;i++);
}
int main(void)
{
  uint8_t i=0,dir=4;
  ddra=0xff;
  ddrb=0xff;
  while(1)
  {
 porta=0x55;
 portb=0xAA;
 delay();
 porta=0xAA;
 portb=0x55;
 delay();
  }
}
