#include<stdint.h>
#define porta (*(volatile uint8_t*)(0x22))
#define  ddra  (*(volatile uint8_t*)(0x21))
#define portb (*(volatile uint8_t*)(0x25))
#define  ddrb  (*(volatile uint8_t*)(0x24))
void delay()
{
  volatile uint32_t i;
  for(i=0;i<400000;i++);
}
int main(void)
{
  ddra=0xff;
  ddrb=0xff;
  while(1)
  {
porta=0xff;
portb=0xff;
delay();
porta=0;
portb=0;
delay();
}
}
